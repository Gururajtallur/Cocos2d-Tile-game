//
//  PPCoins.h
//  PocketPirate
//
//  Created by Gururaj T on 04/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MyGameConfig.h"

@interface PPCoins : CCSprite
{
    
}

-(void)runAnimation;
@end
