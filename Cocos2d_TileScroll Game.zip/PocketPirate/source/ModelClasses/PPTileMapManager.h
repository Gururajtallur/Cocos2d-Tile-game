//
//  PPTileMapManager.h
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MyGameConfig.h"
#import "PPTileMap.h"

@class MyGame;

@interface PPTileMapManager : NSObject
{    
    MyGame          *sGame;
    CCNode          *mParent; 
    
    NSMutableArray  *mTileMapArray;
    
    float           mLevelHeight;
    
    CGPoint            mVelocity;
    
    float           mMapWidth;
    float           mMapHeight;
    float           mMapOffset;
    float           mScreenWidth;
    float           mScreenHeight;
    
    #ifdef USE_THREAD_FOR_LOADING_TILE_MAP
    NSMutableArray  *mLoadedTileMapArray;
    PPTileMap       *mLoadedTileMap;
    #endif
    
    bool        mIsNewTileLoadingStarted;
    
}

@property(nonatomic, assign) CCNode     *parent;
@property(nonatomic, assign) CGPoint    velocity;

-(id)initWithNameParent:(CCNode*)inParent;
-(void)update:(ccTime)dt;
-(void)checkForSpecialTile:(CGPoint)position;
-(void)blinckClickedTile:(CGPoint)position;
-(void)slideMapRight:(bool)isRight;
@end
