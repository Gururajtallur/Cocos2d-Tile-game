//
//  PPCoins.mm
//  PocketPirate
//
//  Created by Gururaj T on 04/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import "PPCoins.h"

@implementation PPCoins

-(void)runAnimation
{
    CCAnimation* animation;
    
    NSMutableArray *animFrames = [NSMutableArray array]; 
    CCSpriteFrameCache *cache = [CCSpriteFrameCache sharedSpriteFrameCache];
      
    for(int i=1;i<=6;i++)
    {
        NSString *file = [NSString stringWithFormat:@"Coin_%d.png",i];
        
        CCSpriteFrame *frame = [cache spriteFrameByName:file];
        [animFrames addObject:frame];
    }
    
    
    animation = [CCAnimation animationWithSpriteFrames:animFrames];
    
    animation.delayPerUnit = 0.3f;
    animation.restoreOriginalFrame = NO;
    
    
    CCAnimate *AnimAction  = [CCAnimate actionWithAnimation:animation];
    
    CCRepeatForever *anim = [CCRepeatForever actionWithAction:AnimAction];
    
    [self runAction:anim];
}


-(void)dealloc
{
    [super dealloc];
}

@end
