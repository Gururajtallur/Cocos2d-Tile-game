//
//  PPTileMap.mm
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import "PPTileMap.h"
#import "PPCoins.h"

@implementation PPTileMap

@synthesize meta = mMetalayer;
@synthesize isOutOfBounds = mIsOutofBounds;
@synthesize mapIndex = mMapIndex;
@synthesize AnimSpriteDict = mAnimDict;
@synthesize tileInfoDict = mTileInfoDict;


//+(id) tiledMapWithTMXFile:(NSString*)tmxFile
//{
//    static int strs = 1;
//    printf("Created %d\n",strs);
//    strs++;
//    return [super tiledMapWithTMXFile:tmxFile];
//}

- (CGPoint)getTileCoordForPosition:(CGPoint)position
{
//    CGPoint nodeSpace1 = [self convertToNodeSpace:position];
//    float x = floor(nodeSpace1.x / self.tileSize.width);
//    float y = floor(self.mapSize.height - (nodeSpace1.y / self.tileSize.height));
//    
//    if( x >= TILE_IN_ROW)
//        x = TILE_IN_ROW - 1;
//    
//    if( y >= TILE_IN_COL)
//        y = TILE_IN_COL - 1;    
//
//    return ccp(x, y);
    
    int maxTileCol = self.mapSize.height;// (_tileMap.contentSize.height)/TILE_SIZE;
    
    int x = ( (position.x-self.position.x)/TILE_SIZE);
    int y = maxTileCol - ( ((position.y)-self.position.y)/TILE_SIZE);
    
    if( x >= TILE_IN_ROW)
        x = TILE_IN_ROW - 1;
    
    if( y >= TILE_IN_COL)
        y = TILE_IN_COL - 1;
    
    return ccp(x, y);

}


//Use this function to identify - Tile is Collidabe or Collectable.

-(GridType)getTileType:(CGPoint)pos 
{        
// not defined USE_COCOS2D_FOR_TILE_IDENTIFICATION
    
#ifdef USE_COCOS2D_FOR_TILE_IDENTIFICATION
    GridType type = kGrideType_Normal;
    
    CGPoint tileCoord = position;//[self tileCoordForPosition:position];
    unsigned int tileGid = [self.meta tileGIDAt:tileCoord];
    if (tileGid) {
        NSDictionary *properties = [self propertiesForGID:tileGid];        
        if (properties)
        {
            NSString *collision = [properties valueForKey:TILE_PROPERTY_COLLIDABLE];
            
            if (collision && [collision caseInsensitiveCompare:@"true"] == NSOrderedSame) 
            {
                type = kGrideType_Collidable ;
            }
            NSString *collectable = [properties valueForKey:TILE_PROPERTY_COLLECTABLE];
            if (collectable && [collectable caseInsensitiveCompare:@"true"] == NSOrderedSame) {
                type = kGrideType_Coin ;
            }
        }
    }
    return type;    
#else
    int type = [[self.tileInfoDict objectForKey:[NSString stringWithFormat:@"TILE(%d,%d)", (int)pos.x,(int)pos.y]] intValue];

    GridType gType = kGrideType_Normal;
    
    if(type!=0)
        gType = (GridType)type;
    
    return (GridType)gType;
#endif
}


-(void)initTileAnimation
{
    self.tileInfoDict   = [[NSMutableDictionary alloc] init];
    self.AnimSpriteDict = [[NSMutableDictionary alloc] init];

    //Parse all the tile in map
    
    CCTMXLayer *bgLayer = [self layerNamed:PP_TILE_MAP_BG_LAYER];
    
    int rowSize = self.mapSize.width ; 
    int colSize = self.mapSize.height ; 
    
    for(int x=0; x<rowSize; x++)
    {
        for (int y=0; y<colSize; y++) 
        {
            CGPoint tileCord = ccp(x,y) ;
            unsigned int tileGid = [self.meta tileGIDAt:tileCord];
          
            GridType tileType = kGrideType_Normal;
            
            NSString *key = [NSString stringWithFormat:@"TILE(%d,%d)", (int)tileCord.x,(int)tileCord.y];

            if (tileGid) 
            {
                NSDictionary *properties = [self propertiesForGID:tileGid];
                
                if (properties)
                {          
                    /* Check Tile :  IS COLLECTABLE - COIN */
                     
                    NSString *collectable = [properties valueForKey:TILE_PROPERTY_COLLECTABLE];
                    
                    if (collectable && [collectable isEqualToString:@"true"]) 
                    {
                        tileType = kGrideType_Collectable;
                        
                        [self.tileInfoDict setObject:[NSNumber numberWithInt:tileType] forKey:key];
                        
                        PPCoins *coinSprite = [PPCoins spriteWithSpriteFrameName:@"Coin_1.png"];
                        coinSprite.tag = kTagCoinSprite;
                        coinSprite.anchorPoint = ccp(0.5f,0.5f);
                        
                        CCSprite *sprite = [bgLayer tileAt:tileCord];
                         
                        coinSprite.position = ccp(sprite.position.x+coinSprite.contentSize.width*0.5f, sprite.position.y+coinSprite.contentSize.height*0.5f) ;
                        
                        [self addChild:coinSprite z:3 tag:kTagCoinSprite];
                        [coinSprite runAnimation];
                        
                        {
                            [self.AnimSpriteDict setObject:coinSprite forKey:key];
                        }
                    }   
                     
                    /* Check Tile :  IS COLLIDABLE - TILE */

                    NSString *collidable = [properties valueForKey:TILE_PROPERTY_COLLIDABLE];
                    
                    if (collidable && [collidable isEqualToString:@"true"]) 
                    {
                        tileType = kGrideType_Collidable;
                        
                        [self.tileInfoDict setObject:[NSNumber numberWithInt:tileType] forKey:key];
                    }
                    
                    /* Check Tile :  IS SEA - TILE */
                    
                    
                    NSString *sea = [properties valueForKey:TILE_PROPERTY_SEA];
                    
                    if (sea && [sea isEqualToString:@"true"]) 
                    {
                        tileType = kGrideType_Sea;
                        
                        [self.tileInfoDict setObject:[NSNumber numberWithInt:tileType] forKey:key];
                    }
                    
                }
                else
                {
                    [self.tileInfoDict setObject:[NSNumber numberWithInt:kGrideType_Normal] forKey:key];
                }
            }
            
        }
    }
}


-(void)processSpecialTiles:(CGPoint)position
{    
    CGPoint point = [self getTileCoordForPosition:position];
    
    GridType type = [self getTileType:point];
    
    if(type == kGrideType_Collectable)
    {
        NSString *key = [NSString stringWithFormat:@"TILE(%d,%d)", (int)point.x,(int)point.y];
          
        PPCoins *coinSprite = [self.AnimSpriteDict objectForKey:key];
        
        if(coinSprite)
        {
            [coinSprite stopAllActions];
            coinSprite.visible = false;
            [coinSprite removeFromParentAndCleanup:YES];
            [self.AnimSpriteDict removeObjectForKey:key];
        }
    }

}

-(void)removeSprite:(id)sender
{
    PPCoins *coins = (PPCoins *)sender;
    [coins removeFromParentAndCleanup:YES];
}

-(void)removeLayers
{
    [self.AnimSpriteDict removeAllObjects];
    
    CCTMXLayer *bgLayer = [self layerNamed:PP_TILE_MAP_BG_LAYER];    
    [bgLayer removeAllChildrenWithCleanup:YES];
    
    [self.meta removeAllChildrenWithCleanup:YES];
    
    [self removeAllChildrenWithCleanup:YES];
}

-(void)dealloc
{
    static int str = 1;
    printf("Removed %d\n",str);
    str++;
    
    if(self.AnimSpriteDict)
    {
        [self.AnimSpriteDict release];
         self.AnimSpriteDict = nil;
    }
    
    if(self.tileInfoDict)
    {
        [self.tileInfoDict release];
        self.tileInfoDict = nil;
    }
    
    [super dealloc];
}
@end
