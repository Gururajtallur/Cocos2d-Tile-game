//
//  PPCannonManager.h
//  PocketPirate
//
//  Created by Gururaj T on 06/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyGameConfig.h"

@interface PPCannonManager : NSObject
{
    CCNode             *mParent;
    
    CCSprite           *mCannonSprite;
    CCSequence         *mCannonAnim;
    
    float               mRotation;
    
    bool                mIsCannonReady;

}
@property(nonatomic, assign) CCSprite *cannonSprite;
@property(nonatomic, assign) float rotation;

-(id)initWithParent:(CCNode*)inParent;
-(void)runCannonAnim;
@end
