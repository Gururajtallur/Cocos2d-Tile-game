//
//  PPGuage.mm
//  PocketPirate
//
//  Created by Gururaj T on 06/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import "PPGuage.h"
#import "MyGameScreen.h"
#import "PPCannonManager.h"

@implementation PPGuage

@synthesize guageBackground = mGuageBackground;
@synthesize trackBall = mTrackBall;

-(id)initWithParent:(CCNode*)inParent
{
    if(self = [super init])
    {
        mParent = inParent;
        
        [self initGaugeSprites];
    }
    return self;
}

-(void)initGaugeSprites
{
    self.guageBackground = [CCSprite spriteWithSpriteFrameName:FRAME_UI_GUAGE];
    self.guageBackground.position = POS_UI_GUAGE;
    [mParent addChild:self.guageBackground z:3 tag:kTagUIGuage];
    
    self.trackBall = [CCSprite spriteWithSpriteFrameName:FRAME_UI_BALL];
    self.trackBall.position = POS_UI_BALL;
    [mParent addChild:self.trackBall z:4 tag:kTagUIBall];

}

-(bool)isGaugeTouched:(CGPoint)inPos
{
    if(CGRectContainsPoint([self.trackBall boundingBox], inPos))
    {
        return true;
    }
    return false;
}

-(void)checkForGuageMove:(CGPoint)inPos
{
    if(CGRectContainsPoint([self.guageBackground boundingBox], inPos))
    {
        float angle;
        
        self.trackBall.position = ccp(inPos.x, self.trackBall.position.y);
        
         
        float slideval = self.trackBall.position.x - mGuageBackground.position.x ;
        float halfGaugeWidth = mGuageBackground.contentSize.width*0.5f;
        angle = slideval * (90/halfGaugeWidth) ;           
        
  
    }
}

-(void)dealloc
{
    [self.guageBackground removeFromParentAndCleanup:YES];
    [self.trackBall removeFromParentAndCleanup:YES];
    
    [super dealloc];
}

@end
