//
//  PPCannonManager.mm
//  PocketPirate
//
//  Created by Gururaj T on 06/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import "PPCannonManager.h"
#import "MyGameScreen.h"


@interface PPCannonManager()
-(void)initCannonAnimSprites;
@end

@implementation PPCannonManager

@synthesize cannonSprite = mCannonSprite;
@synthesize rotation = mRotation;

-(id)initWithParent:(CCNode*)inParent
{
    if(self = [super init])
    {
        mParent = inParent;
        self.rotation = 0.0f;
        
        mIsCannonReady = true;
        
        [self initCannonAnimSprites];
    }
    return self;
}

-(void)initCannonAnimSprites
{    
    self.cannonSprite = [CCSprite spriteWithSpriteFrameName:FRAME_CANNON_ANIM]; 
    self.cannonSprite.position = POS_CANNON;//ccp(s.width*0.5f-8, PIRATE_POSITION_Y+10);
    self.cannonSprite.anchorPoint=ccp(0.5f,0.0f );

    [mParent addChild:self.cannonSprite z:LAYER_CANNON];
    
    CCAnimation* animation;
    
    NSMutableArray *animFrames = [NSMutableArray array]; 
    CCSpriteFrameCache *cache = [CCSpriteFrameCache sharedSpriteFrameCache];
    
    for(int i=0;i<=40;i++)
    {
        NSString *file = [NSString stringWithFormat:@"cannonShoot_%.4d.png",i];
        
        CCSpriteFrame *frame = [cache spriteFrameByName:file];
        [animFrames addObject:frame];
    }
    
    
    animation = [CCAnimation animationWithSpriteFrames:animFrames];
    
    animation.delayPerUnit = 0.1f;
    animation.restoreOriginalFrame = YES;
     
    CCAnimate *AnimAction  = [CCAnimate actionWithAnimation:animation];
    id calFun = [CCCallFunc actionWithTarget:self selector:@selector(animDone)];
    
    mCannonAnim = [[CCSequence actions:AnimAction, calFun, nil] retain];
    
    
   // MyGameScreen *p = (MyGameScreen*)mParent;
   // p.debugSprite   = self.cannonSprite;
 
}

-(void)animDone
{
    mIsCannonReady = true;

}


-(void)runCannonAnim
{
    if(mIsCannonReady)
    {
        mIsCannonReady = false;
        [mCannonSprite runAction:mCannonAnim];
    }
}


-(void)dealloc
{
    if(mCannonAnim)
    {
        [mCannonAnim release];
        mCannonAnim = nil;
    }
    [super dealloc];
}

@end
