//
//  PPTileMapManager.mm
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import "PPTileMapManager.h"
#import "PPTileMap.h"
#import "MyGame.h"

@implementation PPTileMapManager

@synthesize parent = mParent;
@synthesize velocity = mVelocity;

-(id)initWithNameParent:(CCNode*)inParent
{
    if(self=[super init])
    {        
        sGame = [MyGame sharedGameObject];
        
        self.velocity = CGPointZero;
        
        self.parent = inParent;
        
        mTileMapArray = [[NSMutableArray alloc] init];
                
        [self initTileMap];
        
    }
    return self;
}

-(void)initTileMap
{
    CGSize s = [[CCDirector sharedDirector] winSize];

    mMapHeight = TILE_IN_COL*TILE_SIZE;
    mMapWidth  = TILE_IN_ROW*TILE_SIZE;
    mMapOffset = ( TILE_IN_ROW*TILE_SIZE  - s.width )* 0.5f ;
    
    mScreenWidth = [[CCDirector sharedDirector] winSize].width;
    mScreenHeight = [[CCDirector sharedDirector] winSize].height;
    
    PPTileMap *tileMap = [PPTileMap tiledMapWithTMXFile:PP_TILE_MAP_1_1];
    tileMap.mapIndex = 1;
    tileMap.position =  ccp(-mMapOffset,0.0f); 
    [self.parent addChild:tileMap z:LAYER_TILE_MAP tag:kTagTileMap];
    
    [mTileMapArray addObject:tileMap]; 
    
    tileMap.meta = [tileMap layerNamed:PP_TILE_META_LAYER];
    tileMap.meta.visible = NO;
    tileMap.isOutOfBounds = false;
    [tileMap initTileAnimation];

    
    mLevelHeight = TILE_IN_COL*TILE_SIZE;
    
    
//    PPTileMap *tileMap2 = [PPTileMap tiledMapWithTMXFile:PP_TILE_MAP_1_2];
//    tileMap.mapIndex = 2;
//    tileMap2.position =  ccp(-mMapOffset,mLevelHeight); 
//    [self.parent addChild:tileMap2 z:-2 tag:kTagTileMap];
//    
//    [mTileMapArray addObject:tileMap2]; 
//    
//    mLevelHeight = mLevelHeight * 2.0f ;
//    
//    
//    tileMap2.meta = [tileMap2 layerNamed:PP_TILE_META_LAYER];
//    tileMap2.meta.visible = NO;
//    tileMap2.isOutOfBounds = false;    
//    [tileMap2 initTileAnimation];
//
    
    
}

-(void)addNewMap:(CGPoint)pos
{
#ifndef USE_THREAD_FOR_LOADING_TILE_MAP
    static int index = 0;
    
    index++;
    
    if(index > 4)
        index = 1;
    
    NSString *tilemapFile = [NSString stringWithFormat:@"GameData/TileMap/PPTileMap_1_%d.tmx", index];

    PPTileMap *tileMap = [[PPTileMap alloc] initWithTMXFile:tilemapFile];
    tileMap.mapIndex = index;
    tileMap.position = pos; 
    [self.parent addChild:tileMap z:LAYER_TILE_MAP tag:kTagTileMap];
    
    [mTileMapArray addObject:tileMap]; 
    
    tileMap.meta = [tileMap layerNamed:PP_TILE_META_LAYER];
    tileMap.meta.visible = NO;
      
    tileMap.isOutOfBounds = false;
    
    [tileMap initTileAnimation];
#else
    if(!mIsNewTileLoadingStarted)
    {
        mIsNewTileLoadingStarted = true;
        
        mLoadedTileMap = nil;
        
        [NSThread detachNewThreadSelector:@selector(loadTileMapInThread:) toTarget:self withObject:nil];
    }
#endif

}



-(void)update:(ccTime)dt
{
    PPTileMap *topTileMap = [mTileMapArray objectAtIndex:0];
    
    float velocity = self.velocity.x;
    
    NSArray *array = [NSArray arrayWithArray:mTileMapArray];
    for(PPTileMap *tileMap in array)
    {
        if(topTileMap.position.y < tileMap.position.y)
            topTileMap = tileMap;
        
        if(tileMap.position.y > -(mMapHeight) )
        {
            tileMap.position = ccp(tileMap.position.x, tileMap.position.y-sGame.gameSpeed);
        }
        else 
        {
            tileMap.isOutOfBounds = true;
        }
        
        //Update Accelerometer x pos
        
        if(!tileMap.isOutOfBounds)
        {
            CGPoint pos = tileMap.position;
            pos.x -= velocity;
            
            if(pos.x <=-(mMapWidth-mScreenWidth) )
            {
                pos.x = -(mMapWidth-mScreenWidth);
            }
            else if(pos.x>=0.0f)
            {
                pos.x = 0.0f;
            }
            
            tileMap.position = ccp(pos.x, tileMap.position.y);
        }
        else 
        {
            [mTileMapArray removeObject:tileMap];
            [tileMap removeLayers];
            [tileMap removeFromParentAndCleanup:YES];

            //[self performSelector:@selector(removeTileMap:) withObject:tileMap afterDelay:1.5f];
        }
    }
    
    
    if(topTileMap.position.y+mMapHeight <= (mScreenHeight+mScreenHeight*0.5f) )
    {
        [self addNewMap:ccp(topTileMap.position.x, topTileMap.position.y+mMapHeight)];
    }
}

-(void)removeTileMap:(id)sender
{
    PPTileMap *tileMap = (PPTileMap*)sender;
    [tileMap release];
    tileMap = nil;

}

-(PPTileMap*)getCurrentTileMap:(CGPoint)inPosition
{
    for(PPTileMap *tileMap in mTileMapArray)
    {
        CGRect boardRect = CGRectMake(tileMap.position.x, tileMap.position.y, tileMap.contentSize.width, tileMap.contentSize.height);
        
        if(CGRectContainsPoint(boardRect, inPosition) )
        {
            return tileMap;
        }
    }
    
    return nil;
}





-(void)checkForSpecialTile:(CGPoint)position
{
    PPTileMap *tileMap = [self getCurrentTileMap:position];

    if(tileMap)
    {
        [tileMap processSpecialTiles:position];
    }
}





//To test tile map :)
-(void)blinckClickedTile:(CGPoint)position
{
#ifndef DEBUG
    return;
#endif

    PPTileMap *tileMap = [self getCurrentTileMap:position];
    CCTMXLayer *layer = [tileMap layerNamed:PP_TILE_MAP_BG_LAYER];
         
    CGPoint point= [tileMap getTileCoordForPosition:position];
        
    CCSprite *tileN = [layer tileAt:point];
    tileN.opacity = 100;
    
}


//used in simuator only..

-(void)slideMapRight:(bool)isRight
{
    float posUpdate;
    
    if(isRight)
    {
        posUpdate = 5.0f;
    }
    else 
    {
        posUpdate = -5.0f;
    }
    
    for(PPTileMap *tileMap in mTileMapArray)
    {
        if(!tileMap.isOutOfBounds)
        {
            CGPoint pos = tileMap.position;
            pos.x -= posUpdate;
            
            if(pos.x <=-(mMapWidth-mScreenWidth) )
            {
                pos.x = -(mMapWidth-mScreenWidth);
            }
            else if(pos.x>=0.0f)
            {
                pos.x = 0.0f;
            }
            
            tileMap.position = ccp(pos.x, tileMap.position.y);
        }
    }

}

#ifdef USE_THREAD_FOR_LOADING_TILE_MAP

//-------------  LOADING THREADS -------------------------


-(void)loadTileMapInThread:(id)argument
{
    NSAutoreleasePool *autoreleasepool = [[NSAutoreleasePool alloc] init];
	CCGLView *view = (CCGLView*)[[CCDirector sharedDirector] view];
    EAGLContext *auxGLcontext = [[EAGLContext alloc]
                                 initWithAPI:kEAGLRenderingAPIOpenGLES2
                                 sharegroup:[[view context] sharegroup]];
    
    if( [EAGLContext setCurrentContext:auxGLcontext] ) {
        
		[self LoadTilesMap];
		
		glFlush();
		
		[EAGLContext setCurrentContext:nil];
	} else {
		CCLOG(@"cocos2d: ERROR: TetureCache: Could not set EAGLContext");
	}
    
    [auxGLcontext release];
	
	[autoreleasepool release];
}

-(void)LoadTilesMap
{
    static int index = 0;
    
    index++;
    if(index > 4)
        index = 1;
    
    NSString *tilemapFile = [NSString stringWithFormat:@"GameData/TileMap/PPTileMap_1_%d.tmx", index];
    
    mLoadedTileMap = [[PPTileMap alloc] initWithTMXFile:tilemapFile];
    mLoadedTileMap.mapIndex = index;
     
    //mLoadedTileMap.meta = [mLoadedTileMap layerNamed:PP_TILE_META_LAYER];
    //mLoadedTileMap.meta.visible = NO;
    //mLoadedTileMap.isOutOfBounds = false;
   // [mLoadedTileMap initTileAnimation];
    
    
    [self performSelector:@selector(doneLoading:) onThread:[[CCDirector sharedDirector] runningThread] withObject:nil waitUntilDone:NO];
}

-(void) doneLoading:(id)argument
{
    //find topTileMap
    PPTileMap *topMap = [mTileMapArray objectAtIndex:0];
    
    for(PPTileMap *tileMap in mTileMapArray)
    {
        if(topMap.position.y<tileMap.position.y)
        {
            topMap = tileMap;
            break;
        }
    }
    
    PPTileMap *tileMap = mLoadedTileMap;
    
    tileMap.position   = ccp(topMap.position.x, topMap.position.y+mMapHeight); 
    tileMap.meta = [tileMap layerNamed:PP_TILE_META_LAYER];
    tileMap.meta.visible = NO;
    tileMap.isOutOfBounds = false;
    [tileMap initTileAnimation];

    
    [self.parent addChild:tileMap z:LAYER_TILE_MAP tag:kTagTileMap];
    
    
    [mTileMapArray addObject:tileMap]; 
    
    mIsNewTileLoadingStarted = false;
}

//-----------------------------------------------------------------

#endif //USE_THREAD_FOR_LOADING_TILE_MAP



-(void)dealloc
{
    
    for(PPTileMap *tileMap in mTileMapArray)
    {
        [tileMap removeFromParentAndCleanup:YES];
    }
    
    if(mTileMapArray)
    {
        [mTileMapArray release];
        mTileMapArray = nil;
    }
    [super dealloc];
}

@end
