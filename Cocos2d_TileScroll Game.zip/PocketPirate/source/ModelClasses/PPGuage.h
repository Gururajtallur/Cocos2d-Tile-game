//
//  PPGuage.h
//  PocketPirate
//
//  Created by Gururaj T on 06/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MyGameConfig.h"

@interface PPGuage : NSObject
{
    CCSprite           *mGuageBackground;
    CCSprite           *mTrackBall;
    
    CCNode             *mParent;
}
@property(nonatomic, assign) CCSprite *guageBackground;
@property(nonatomic, assign) CCSprite *trackBall;

-(id)initWithParent:(CCNode*)inParent;
-(bool)isGaugeTouched:(CGPoint)inPos;
-(void)checkForGuageMove:(CGPoint)inPos;
@end
