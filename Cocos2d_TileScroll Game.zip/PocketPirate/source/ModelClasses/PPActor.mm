//
//  PPActor.mm
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import "PPActor.h"
#import "MyGame.h"

@implementation PPActor

@synthesize parentLayer = mParentLayer;

+(id)initWithParent:(CCNode*)inParent
{
    CGSize s = [[CCDirector sharedDirector] winSize];
    
    PPActor *actor;
    
    actor = [PPActor spriteWithSpriteFrameName:FRAM_ACTOR_1];
    actor.position = ccp(s.width*0.5f, PIRATE_POSITION_Y) ;  
    actor.parentLayer = inParent;
    actor.tag = kTagGameActor;
    actor.anchorPoint=ccp(0.5f, 0.5f);
    
    [inParent addChild:actor z:LAYER_PIRATE tag:kTagGameActor];
    
    [actor initAnim];

    return actor;
}

-(void)initAnim
{
    CCAnimation* animation;
    
    NSMutableArray *animFrames = [NSMutableArray array]; 
    CCSpriteFrameCache *cache = [CCSpriteFrameCache sharedSpriteFrameCache];
    
    for(int i=0;i<=40;i++)
    {
        NSString *file = [NSString stringWithFormat:@"Pirate_%d.png",i];
        
        CCSpriteFrame *frame = [cache spriteFrameByName:file];
        [animFrames addObject:frame];
    }
    
    
    animation = [CCAnimation animationWithSpriteFrames:animFrames];
    
    animation.delayPerUnit = 0.1f;
    animation.restoreOriginalFrame = NO;
    
    
    CCAnimate *AnimAction  = [CCAnimate actionWithAnimation:animation];
    
    CCRepeatForever *anim = [CCRepeatForever actionWithAction:AnimAction];
    
    [self runAction:anim];

}

@end
