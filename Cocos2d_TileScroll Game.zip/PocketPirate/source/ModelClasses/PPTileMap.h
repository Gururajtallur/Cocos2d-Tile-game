//
//  PPTileMap.h
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyGameConfig.h"
#import "HKTMXTiledMap.h"

@class MyGame;

@interface PPTileMap : CCTMXTiledMap//HKTMXTiledMap
{
//    HKTMXLayer *mMetalayer;
    
    CCTMXLayer *mMetalayer;
    
    bool        mIsOutofBounds;
    
    MyGame      *sGame;
    
    int         mMapIndex;
    
    NSMutableDictionary    *mAnimDict;
    
    NSMutableDictionary    *mTileInfoDict;

}
@property(nonatomic, assign) CCTMXLayer *meta;
@property(nonatomic, assign) bool isOutOfBounds;
@property(nonatomic, assign) int mapIndex;
@property (nonatomic, retain) NSMutableDictionary    *AnimSpriteDict;
@property (nonatomic, retain) NSMutableDictionary    *tileInfoDict;


- (CGPoint)getTileCoordForPosition:(CGPoint)pos;
-(GridType)getTileType:(CGPoint)pos;
-(void)initTileAnimation;
-(void)processSpecialTiles:(CGPoint)position;
-(void)removeLayers;
@end
