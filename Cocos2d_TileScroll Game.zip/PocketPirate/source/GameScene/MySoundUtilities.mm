//
//  MySoundUtilities.mm
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import "MySoundUtilities.h"
#import "SimpleAudioEngine.h"
#import "MyGameConfig.h"
#import "MyGame.h"

@implementation MySoundUtilities

-(id)init
{
    if(self = [super init])
    {
       // [self PreLoadClickSoundEffect];
    }
    return self;
}


-(void)PreLoadClickSoundEffect
{
    [[SimpleAudioEngine sharedEngine]  preloadEffect:kSoundTap];
}


- (void)PlayClick 
{
//    if([[MyGame sharedGameObject] isMusicOn])
//        [[SimpleAudioEngine sharedEngine] playEffect:kSoundTap] ;
}

@end
