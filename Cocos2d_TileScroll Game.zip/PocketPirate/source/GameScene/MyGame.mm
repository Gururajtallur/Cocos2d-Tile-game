//
//  MyGame.mm
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import "MyGame.h"
#import "MyMainMenu.h"
#import "MyGameScreen.h"

static MyGame *gGame = nil;

@interface MyGame()

@end

@implementation MyGame

@synthesize  gameSpeed = mGameSpeed;
@synthesize  currentScene = mScene;
@synthesize  previousScene = mPrevScene;
@synthesize  layer = mLayer;
@synthesize  Sound = mSound;
@synthesize  isMusicOn = mIsMusicOn; 

@synthesize  IsIpad = mIsIpad;
@synthesize isRetinaDisplay = mIsRetinaDisplay; 

+(MyGame*)sharedGameObject
{
    if(!gGame)
    {
        gGame = [[MyGame alloc] init];
    }
    return gGame;
}


-(id)init
{
    if(self = [super init])
    {
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            mIsIpad =  true;
        }
        else {
            mIsIpad = false;
        }
        
        self.gameSpeed = 5.0f;
        
        // mScene = kFlashScreen;
        mScene = kSceneMainMenu;
        mPrevScene = kSceneMainMenu;
         
        mIsMusicOn = true;
        srand (time(NULL));
        
        mSound = [[MySoundUtilities alloc] init];
        
        //Register User deaults..
        NSString *userDefaultsValuesPath=[[NSBundle mainBundle] pathForResource:@"Preferences" ofType:@"plist"];
        
        NSDictionary * userDefaultsValuesDict=[NSDictionary dictionaryWithContentsOfFile:userDefaultsValuesPath];
        // set them in the standard user defaults
        [[NSUserDefaults standardUserDefaults] registerDefaults:userDefaultsValuesDict];
        
        //[MyGameCenterManager sharedMyGamecenter];
        
    }
    return  self;
}

-(int)getRandomVal:(int)min range:(int)max
{
    int maxSafe = max+1;
    
    int val = (int)((rand()%(maxSafe-min))+ min);
    
    if(val == maxSafe)
        val-=1;
    
    return val;
}

-(CGRect)getSpriteRect:(CCNode *)inSprite
{
    CGRect sprRect = CGRectMake(
                                inSprite.position.x - inSprite.contentSize.width*inSprite.anchorPoint.x,
                                inSprite.position.y - inSprite.contentSize.height*inSprite.anchorPoint.y,
                                inSprite.contentSize.width, 
                                inSprite.contentSize.height
                                ); 
    
    return sprRect;
}
 

-(void)savePreference
{
    NSMutableArray *PlayerArray = [[NSMutableArray alloc] init];
    /* Save carrom coin position */
    
    NSDictionary *PlayerDict = [NSDictionary dictionaryWithObjectsAndKeys:        
                                /* [NSNumber numberWithInt:mLevel], @"Level",*/
                                [NSNumber numberWithBool:mIsMusicOn],@"isGameMusicOn",
                                
                                nil
                                ];
    
    
    [PlayerArray addObject:PlayerDict];
    [[NSUserDefaults standardUserDefaults] setObject:PlayerArray forKey:@"MyGameSettings"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [PlayerArray release];
    
}

-(void)loadpreference
{
    NSArray *array = [[NSUserDefaults standardUserDefaults] objectForKey:@"MyGameSettings"];
    
    for (NSDictionary *playerDict in array) 
    {
        mIsMusicOn    =  [[playerDict objectForKey:@"isGameMusicOn"] boolValue];        
    }
}



-(Class)getCurrentTransition:(float &)interval
{
    Class transition ;
    
    if(mPrevScene == kSceneMainMenu && mScene == kSceneGameScreen)
    {
        interval = 1.0f;
        transition = NSClassFromString(@"CCTransitionFade") ;
    }
    else if(mPrevScene == kSceneGameScreen && mScene == kSceneGameScreen)
    {
        interval = 0.5f;
        transition = NSClassFromString(@"CCTransitionFade") ;
    }
    else
    {
        transition = NSClassFromString(@"TransitionPageForward") ;
    }
    
    return transition;
}

-(void)playGameScene:(GameScreen)inScreen
{
    self.currentScene = inScreen;
    [self SetCurrentScene];
}

-(void)SetCurrentScene
{
    float duration = 1.0f;
    Class transition  = [self getCurrentTransition:duration];
    
    switch (mScene)
    {
        case kSceneMainMenu:
            [[CCDirector sharedDirector] replaceScene:[transition transitionWithDuration:duration scene:[MyMainMenu scene]]];
            
            break;      
        case kSceneGameScreen:
            [[CCDirector sharedDirector] replaceScene:[transition transitionWithDuration:duration scene:[MyGameScreen scene]]];            
            break;
            
        default:
            break;
    }
    
    mPrevScene = mScene;
    
}


- (void) showAlertWithTitle: (NSString*) title message: (NSString*) message
{
	UIAlertView* alert= [[[UIAlertView alloc] initWithTitle: title message: message 
                                                   delegate: NULL cancelButtonTitle: @"OK" otherButtonTitles: NULL] autorelease];
	[alert show];
	
}

 

-(void)InitUsefultextureCache
{
    CCSpriteFrameCache *cache = [CCSpriteFrameCache sharedSpriteFrameCache];
    
//    if(self.IsIpad)
//    {
//        [cache addSpriteFramesWithFile:IPAD_GM_SPRITE_SHEET_COORD textureFilename:IPAD_GAME_SPRITE_SHEET];
//    }
//    else 
    {
        [cache addSpriteFramesWithFile:SPRITE_COORD_1 textureFilename:SPRITE_SHEET_1];
    }
}

-(void)runWithScene
{
    //Do common loading part here...
    [self InitUsefultextureCache];
    [[CCDirector sharedDirector] pushScene: [MyMainMenu scene]];
}

-(b2Vec2) toB2Meters:(CGPoint)point 
{
	return b2Vec2(point.x / PTM_RATIO, point.y / PTM_RATIO);
}

-(CGPoint) toPixel:(b2Vec2)point 
{
	return CGPointMake(point.x * PTM_RATIO, point.y * PTM_RATIO);
}


-(void)dealloc
{
    CCSpriteFrameCache *cache = [CCSpriteFrameCache sharedSpriteFrameCache];
    
    [cache removeSpriteFramesFromFile:@"GameData/usefulTextures.plist"];
    
    [super dealloc];
}


@end
