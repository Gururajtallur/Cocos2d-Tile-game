//
//  MyMainMenu.mm
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import "MyMainMenu.h"
#import "MyGame.h"

@implementation MyMainMenu

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	MyMainMenu *layer = [MyMainMenu node];
	
    MyGame *game = [MyGame sharedGameObject];
    game.layer = layer;
    
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

-(void)onEnter
{
    [super onEnter];
    
    self.isTouchEnabled = YES;
    
    sGame = [MyGame sharedGameObject];
    
//    [self setupBackground];
//    
//    [self setupMenu];
}

#pragma mark TouchesMethod

- (void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//    UITouch *myTouch = [touches anyObject];
//    CGPoint location = [myTouch locationInView:[myTouch view]];
//    location = [[CCDirector sharedDirector] convertToGL:location];
    
    
    sGame.currentScene = kSceneGameScreen;
    [sGame SetCurrentScene];
    
}

- (void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
//    UITouch *touch = [touches anyObject];
//      
//    CGPoint touchLocation = [touch locationInView: [touch view]];
//    touchLocation = [[CCDirector sharedDirector] convertToGL:touchLocation];
    
 
}

- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
//    UITouch *touch = [touches anyObject];
//    
//    CGPoint location = [touch locationInView: [touch view]];
//    location = [[CCDirector sharedDirector] convertToGL: location];

}


@end
