//
//  MySceneTransition.h
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//


#ifndef MY_SCENE_TRANSITION_H
#define MY_SCENE_TRANSITION_H

#import <Foundation/Foundation.h>

#import "cocos2d.h"

@interface FadeWhiteTransition : CCTransitionFade
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface FlipXLeftOver : CCTransitionFlipX 
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface FlipXRightOver : CCTransitionFlipX 
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface FlipYUpOver : CCTransitionFlipY 
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface FlipYDownOver : CCTransitionFlipY 
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface FlipAngularLeftOver : CCTransitionFlipAngular 
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface FlipAngularRightOver : CCTransitionFlipAngular 
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface ZoomFlipXLeftOver : CCTransitionZoomFlipX 
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface ZoomFlipXRightOver : CCTransitionZoomFlipX 
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface ZoomFlipYUpOver : CCTransitionZoomFlipY 
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface ZoomFlipYDownOver : CCTransitionZoomFlipY 
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface ZoomFlipAngularLeftOver : CCTransitionZoomFlipAngular 
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface ZoomFlipAngularRightOver : CCTransitionZoomFlipAngular 
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface TransitionPageForward : CCTransitionPageTurn
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end
@interface TransitionPageBackward : CCTransitionPageTurn
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s;
@end

@interface Shaky3DDemo : CCShaky3D
+(id) actionWithDuration:(ccTime)t;
@end
@interface Waves3DDemo : CCWaves3D
+(id) actionWithDuration:(ccTime)t;
@end
@interface FlipX3DDemo : CCFlipX3D
+(id) actionWithDuration:(ccTime)t;
@end
@interface FlipY3DDemo : CCFlipY3D
+(id) actionWithDuration:(ccTime)t;
@end
@interface Lens3DDemo : CCLens3D
+(id) actionWithDuration:(ccTime)t;
@end
@interface Ripple3DDemo : CCRipple3D
+(id) actionWithDuration:(ccTime)t;
@end
@interface LiquidDemo : CCLiquid
+(id) actionWithDuration:(ccTime)t;
@end
@interface WavesDemo : CCWaves
+(id) actionWithDuration:(ccTime)t;
@end
@interface TwirlDemo : CCTwirl
+(id) actionWithDuration:(ccTime)t;
@end
@interface ShakyTiles3DDemo : CCShakyTiles3D
+(id) actionWithDuration:(ccTime)t;
@end
@interface ShatteredTiles3DDemo : CCShatteredTiles3D
+(id) actionWithDuration:(ccTime)t;
@end
@interface ShuffleTilesDemo : CCShuffleTiles
+(id) actionWithDuration:(ccTime)t;
@end
@interface FadeOutTRTilesDemo : CCFadeOutTRTiles
+(id) actionWithDuration:(ccTime)t;
@end
@interface FadeOutBLTilesDemo : CCFadeOutBLTiles
+(id) actionWithDuration:(ccTime)t;
@end
@interface FadeOutUpTilesDemo : CCFadeOutUpTiles
+(id) actionWithDuration:(ccTime)t;
@end
@interface FadeOutDownTilesDemo : CCFadeOutDownTiles
+(id) actionWithDuration:(ccTime)t;
@end
@interface TurnOffTilesDemo : CCTurnOffTiles
+(id) actionWithDuration:(ccTime)t;
@end
@interface WavesTiles3DDemo : CCWavesTiles3D
+(id) actionWithDuration:(ccTime)t;
@end
@interface JumpTiles3DDemo : CCJumpTiles3D
+(id) actionWithDuration:(ccTime)t;
@end
@interface SplitRowsDemo : CCSplitRows
+(id) actionWithDuration:(ccTime)t;
@end
@interface SplitColsDemo : CCSplitCols
+(id) actionWithDuration:(ccTime)t;
@end
@interface PageTurn3DDemo : CCPageTurn3D
+(id) actionWithDuration:(ccTime)t;
@end




#endif