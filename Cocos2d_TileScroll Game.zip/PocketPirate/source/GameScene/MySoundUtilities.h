//
//  MySoundUtilities.h
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MySoundUtilities : NSObject
{
    
}
-(void)PlayClick ;
@end
