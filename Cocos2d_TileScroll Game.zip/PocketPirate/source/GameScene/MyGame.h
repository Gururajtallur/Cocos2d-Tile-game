//
//  MyGame.h
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "cocos2d.h"
#import "MySoundUtilities.h"
#import "MyGameConfig.h"

@interface MyGame : NSObject
{
    GameScreen          mScene;
    GameScreen          mPrevScene;        
    
    CCLayer             *mLayer;
    MySoundUtilities    *mSound;
    
    bool                mIsMusicOn;
    
    bool                mIsIpad;
    bool                mIsRetinaDisplay;
    
    float               mGameSpeed;
}
@property(nonatomic,assign) float       gameSpeed;
@property(nonatomic,assign) bool        isMusicOn;
@property(nonatomic,assign) GameScreen  currentScene;
@property(nonatomic,assign) GameScreen  previousScene;
@property(nonatomic,retain) CCLayer     *layer;
@property(nonatomic,readonly) bool      IsIpad;
@property(nonatomic,assign) bool        isRetinaDisplay;
@property(nonatomic,retain) MySoundUtilities    *Sound ;


-(void)loadpreference;
-(void)savePreference;
-(CGRect)getSpriteRect:(CCNode *)inSprite;
+ (MyGame *)sharedGameObject;
-(int)getRandomVal:(int)min range:(int)max;
-(void)runWithScene;
-(void)SetCurrentScene;
-(b2Vec2) toB2Meters:(CGPoint)point;
-(CGPoint) toPixel:(b2Vec2)point ;
- (void) showAlertWithTitle: (NSString*) title message: (NSString*) message;
-(void)InitUsefultextureCache;
@end
