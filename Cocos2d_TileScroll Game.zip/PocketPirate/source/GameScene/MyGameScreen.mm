//
//  MyGameScreen.mm
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import "MyGameScreen.h"
#import "MyGame.h"
#import "PPTileMapManager.h"
#import "AppDelegate.h"
#import "PPActor.h"
#import "PPGuage.h"

@interface MyGameScreen()
-(void)setupUI;
-(void)setupBackground;
-(void)loadSpriteSheet;
@end


@implementation MyGameScreen

@synthesize tileManager = mTileManager;
@synthesize gameActor = mGameActor;
 

#ifdef DEBUG
@synthesize  debugSprite = mDebugSprite;
#endif

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	MyGameScreen *layer = [MyGameScreen node];
	
    MyGame *game = [MyGame sharedGameObject];
    game.layer = layer;
    
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

-(void)onEnter
{
    [super onEnter];
    
    [self loadSpriteSheet];
    
    self.isTouchEnabled = true;
    self.isAccelerometerEnabled = true;
    mAllowGageChange = false;
    
    mIsGamePaused = false;
    
    sGame = [MyGame sharedGameObject];
    
    [self setupBackground];
    [self setupUI];
    
    [self initGameBoard];
    
    self.gameActor = [PPActor initWithParent:self];
      
    [self schedule: @selector(tick:) interval:0.015f];
 }


-(void)loadSpriteSheet
{
    CCSpriteFrameCache *cache = [CCSpriteFrameCache sharedSpriteFrameCache];
    
    [cache addSpriteFramesWithFile:UI_SPRITE_COORD_1 textureFilename:UI_SPRITE_SHEET_1];
    [cache addSpriteFramesWithFile:CANNON_SPRITE_COORD_1 textureFilename:CANNON_SPRITE_SHEET_1];

}

-(void)setupBackground
{
//    CGSize s = [[CCDirector sharedDirector] winSize];
//    CCSprite *bg = [CCSprite spriteWithFile:@"GameData/bgref.png"];
//    bg.position = ccp(s.width/2.0f,s.height/2.0f);
//    [self addChild:bg z:3];
}

-(void)setupUI
{
    return;
    
    CCSprite *route = [CCSprite spriteWithSpriteFrameName:FRAME_UI_ROUTE];
    route.position = POS_UI_ROUTE;
    [self addChild:route z:3 tag:kTagUIRoute];

    CCSprite *chest = [CCSprite spriteWithSpriteFrameName:FRAME_UI_CHEST];
    chest.position = POS_UI_CHEST;
    [self addChild:chest z:3 tag:kTagUIChest];
        
    CCSprite *coins = [CCSprite spriteWithSpriteFrameName:FRAME_UI_COINS];
    coins.position = POS_UI_COINS;
    [self addChild:coins z:3 tag:kTagUICoins];

    CCSprite *targets = [CCSprite spriteWithSpriteFrameName:FRAME_UI_TARGETS];
    targets.position = POS_UI_TARGET;
    [self addChild:targets z:3 tag:kTagUITargets];
    
    CCSprite *inkyPirate = [CCSprite spriteWithSpriteFrameName:FRAME_UI_INKY_PI];
    inkyPirate.position = POS_UI_START_INKY;
    [self addChild:inkyPirate z:3 tag:kTagUIInkyPirate];
    
    CCSprite *Pirate = [CCSprite spriteWithSpriteFrameName:FRAME_UI_PIRATES];
    Pirate.position = POS_UI_START_PIRATE;
    [self addChild:Pirate z:3 tag:kTagUIPirate];     
}

-(void)speedUpGame :(ccTime)dt
{
    sGame.gameSpeed += 1.0f ;
        
    int maxSpeed = MAX_GAME_SPEED;
    
    if(sGame.gameSpeed > maxSpeed)
        sGame.gameSpeed = maxSpeed ;
}


#pragma mark - tick - 

-(void) tick: (ccTime) dt
{ 
    
    if(mIsGamePaused)
    {
        return;
    }
    
    [self.tileManager update:dt];
    [self updateActor];
}



-(void)updateActor
{
    [self.tileManager checkForSpecialTile:self.gameActor.position];
    
}



-(void)initGameBoard
{
    self.tileManager = [[PPTileMapManager alloc] initWithNameParent:self];
                        
}

#pragma mark - Accelerometer Method - 

-(void) accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration
{   
    
//    if(self.isGameOver || self.isGamePaused)
//        return;
    
    //float deceleration = 0.1f, sensitivity = 8.0f, maxVelocity = 150;
    
    float deceleration = 0.1f, sensitivity = 8.0f, maxVelocity = 250;
    
    AppController *app = (AppController*)[UIApplication sharedApplication].delegate;
    
    
    if(sGame.IsIpad)
    {
        sensitivity = 14.0f;
        maxVelocity = 450;
    }
    
    // adjust velocity based on current accelerometer acceleration
    //    vel.x = vel.x * deceleration + acceleration.x * sensitivity;
    
    float velocity_x = self.tileManager.velocity.x;
    
    
    if(app.orient == UIInterfaceOrientationPortraitUpsideDown)
    {
        velocity_x = velocity_x * deceleration + (-acceleration.x) * sensitivity;        
    }
    else 
    {
        velocity_x = velocity_x * deceleration + acceleration.x * sensitivity;
    }
    
    
    //limit the maximum velocity of the player sprite, in both directions (positive & negative values)
    velocity_x = fmaxf(fminf(velocity_x, maxVelocity), -maxVelocity);
    
    self.tileManager.velocity  = ccp(velocity_x, self.tileManager.velocity.y);
    
}


#pragma mark TouchesMethod

- (void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *myTouch = [touches anyObject];
    CGPoint location = [myTouch locationInView:[myTouch view]];
    location = [[CCDirector sharedDirector] convertToGL:location];
    
         
#if TARGET_IPHONE_SIMULATOR
    mPrevTouch = location;
   // [self.tileManager blinckClickedTile:location];
#endif
    
    
}

- (void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
      
    CGPoint touchLocation = [touch locationInView: [touch view]];
    touchLocation = [[CCDirector sharedDirector] convertToGL:touchLocation];

     
    
    #ifdef DEBUG
    if(self.debugSprite)
    {
        self.debugSprite.position = touchLocation;
        printf("ccp(%.1f,%.1f)\n",touchLocation.x,touchLocation.y);
    }
    #endif
    
    
    #if TARGET_IPHONE_SIMULATOR
    
    if(touchLocation.x > mPrevTouch.x)
    {
        [self.tileManager slideMapRight:true];
    }
    else
    {
        [self.tileManager slideMapRight:false];
    }
    
    mPrevTouch = touchLocation;
    #endif
    
}

- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    //    UITouch *touch = [touches anyObject];
    //    
    //    CGPoint location = [touch locationInView: [touch view]];
    //    location = [[CCDirector sharedDirector] convertToGL: location];
    
}

-(void)onExit
{
    CCSpriteFrameCache *cache = [CCSpriteFrameCache sharedSpriteFrameCache];
        
    [cache removeSpriteFramesFromFile:UI_SPRITE_COORD_1];
    [cache removeSpriteFramesFromFile:CANNON_SPRITE_COORD_1];
 
    
    
    [super onExit];
}

-(void)dealloc
{
    if(self.tileManager)
    {
        [self.tileManager release];
    }
    [super dealloc];
}


@end
