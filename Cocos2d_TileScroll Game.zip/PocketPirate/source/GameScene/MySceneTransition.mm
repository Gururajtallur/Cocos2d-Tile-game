//
//  MySceneTransition.mm
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import "MySceneTransition.h"

@implementation FlipXLeftOver
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s orientation:kOrientationLeftOver];
}
@end
@implementation FadeWhiteTransition
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s withColor:ccWHITE];
}
@end

@implementation FlipXRightOver
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s orientation:kOrientationRightOver];
}
@end
@implementation FlipYUpOver
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s orientation:kOrientationUpOver];
}
@end
@implementation FlipYDownOver
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s orientation:kOrientationDownOver];
}
@end
@implementation FlipAngularLeftOver
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s orientation:kOrientationLeftOver];
}
@end
@implementation FlipAngularRightOver
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s orientation:kOrientationRightOver];
}
@end
@implementation ZoomFlipXLeftOver
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s orientation:kOrientationLeftOver];
}
@end
@implementation ZoomFlipXRightOver
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s orientation:kOrientationRightOver];
}
@end
@implementation ZoomFlipYUpOver
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s orientation:kOrientationUpOver];
}
@end
@implementation ZoomFlipYDownOver
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s orientation:kOrientationDownOver];
}
@end
@implementation ZoomFlipAngularLeftOver
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s orientation:kOrientationLeftOver];
}
@end
@implementation ZoomFlipAngularRightOver
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s orientation:kOrientationRightOver];
}
@end

@implementation TransitionPageForward
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s backwards:NO];
}
@end

@implementation TransitionPageBackward
+(id) transitionWithDuration:(ccTime) t scene:(CCScene*)s {
	return [self transitionWithDuration:t scene:s backwards:YES];
}

@end



@implementation Shaky3DDemo
+(id) actionWithDuration:(ccTime)t
{
	return [self actionWithRange:5 shakeZ:NO grid:ccg(15,10) duration:t];
}
@end
@implementation Waves3DDemo
+(id) actionWithDuration:(ccTime)t
{
	return [self actionWithWaves:5 amplitude:40 grid:ccg(15,10) duration:t];
}
@end
@implementation FlipX3DDemo
+(id) actionWithDuration:(ccTime)t
{
	id flipx  = [CCFlipX3D actionWithDuration:t];
	id flipx_back = [flipx reverse];
	id delay = [CCDelayTime actionWithDuration:2];
    
	return [CCSequence actions: flipx, delay, flipx_back, nil];
}
@end
@implementation FlipY3DDemo
+(id) actionWithDuration:(ccTime)t
{
	id flipy = [CCFlipY3D actionWithDuration:t];
	id flipy_back = [flipy reverse];
	id delay = [CCDelayTime actionWithDuration:2];
    
	return [CCSequence actions: flipy, delay, flipy_back, nil];
}
@end
@implementation Lens3DDemo
+(id) actionWithDuration:(ccTime)t
{
	CGSize size = [[CCDirector sharedDirector] winSize];
	return [self actionWithPosition:ccp(size.width/2,size.height/2) radius:240 grid:ccg(15,10) duration:t];
}
@end
@implementation Ripple3DDemo
+(id) actionWithDuration:(ccTime)t
{
	CGSize size = [[CCDirector sharedDirector] winSize];
	return [self actionWithPosition:ccp(size.width/2,size.height/2) radius:240 waves:4 amplitude:160 grid:ccg(32,24) duration:t];
}
@end
@implementation LiquidDemo
+(id) actionWithDuration:(ccTime)t
{
	return [self actionWithWaves:4 amplitude:20 grid:ccg(16,12) duration:t];
}
@end
@implementation WavesDemo
+(id) actionWithDuration:(ccTime)t
{
	return [self actionWithWaves:4 amplitude:20 horizontal:YES vertical:YES grid:ccg(16,12) duration:t];
}
@end
@implementation TwirlDemo
+(id) actionWithDuration:(ccTime)t
{
	CGSize size = [[CCDirector sharedDirector] winSize];
	return [self actionWithPosition:ccp(size.width/2, size.height/2) twirls:1 amplitude:2.5f grid:ccg(12,8) duration:t];
}
@end
@implementation ShakyTiles3DDemo
+(id) actionWithDuration:(ccTime)t
{
	return [self actionWithRange:5 shakeZ:NO grid:ccg(16,12) duration:t];
}
@end
@implementation ShatteredTiles3DDemo
+(id) actionWithDuration:(ccTime)t
{
	return [self actionWithRange:5 shatterZ:NO grid:ccg(16,12) duration:t];
}
@end
@implementation ShuffleTilesDemo
+(id) actionWithDuration:(ccTime)t
{
	id shuffle = [CCShuffleTiles actionWithSeed:25 grid:ccg(16,12) duration:t];
	id shuffle_back = [shuffle reverse];
	id delay = [CCDelayTime actionWithDuration:2];
    
	return [CCSequence actions: shuffle, delay, shuffle_back, nil];
}
@end
@implementation FadeOutTRTilesDemo
+(id) actionWithDuration:(ccTime)t
{
	id fadeout = [CCFadeOutTRTiles actionWithSize:ccg(16,12) duration:t];
	id back = [fadeout reverse];
	id delay = [CCDelayTime actionWithDuration:0.5f];
    
	return [CCSequence actions: fadeout, delay, back, nil];
}
@end
@implementation FadeOutBLTilesDemo
+(id) actionWithDuration:(ccTime)t
{
	id fadeout = [CCFadeOutBLTiles actionWithSize:ccg(16,12) duration:t];
	id back = [fadeout reverse];
	id delay = [CCDelayTime actionWithDuration:0.5f];
    
	return [CCSequence actions: fadeout, delay, back, nil];
}
@end
@implementation FadeOutUpTilesDemo
+(id) actionWithDuration:(ccTime)t
{
	id fadeout = [CCFadeOutUpTiles actionWithSize:ccg(16,12) duration:t];
	id back = [fadeout reverse];
	id delay = [CCDelayTime actionWithDuration:0.5f];
    
	return [CCSequence actions: fadeout, delay, back, nil];
}
@end
@implementation FadeOutDownTilesDemo
+(id) actionWithDuration:(ccTime)t
{
	id fadeout = [CCFadeOutDownTiles actionWithSize:ccg(16,12) duration:t];
	id back = [fadeout reverse];
	id delay = [CCDelayTime actionWithDuration:0.5f];
    
	return [CCSequence actions: fadeout, delay, back, nil];
}
@end
@implementation TurnOffTilesDemo
+(id) actionWithDuration:(ccTime)t
{
	id action = [CCTurnOffTiles actionWithSeed:25 grid:ccg(48,32) duration:t];
	id back = [action reverse];
	id delay = [CCDelayTime actionWithDuration:0.5f];
    
	return [CCSequence actions: action, delay, back, nil];
}
@end
@implementation WavesTiles3DDemo
+(id) actionWithDuration:(ccTime)t
{
	return [self actionWithWaves:4 amplitude:120 grid:ccg(15,10) duration:t];
}
@end
@implementation JumpTiles3DDemo
+(id) actionWithDuration:(ccTime)t
{
	return [self actionWithJumps:2 amplitude:30 grid:ccg(15,10) duration:t];
}
@end
@implementation SplitRowsDemo
+(id) actionWithDuration:(ccTime)t
{
	return [self actionWithRows:9 duration:t];
}
@end
@implementation SplitColsDemo
+(id) actionWithDuration:(ccTime)t
{
	return [self actionWithCols:9 duration:t];
}
@end

@implementation PageTurn3DDemo
+(id) actionWithDuration:(ccTime)t
{
	return [self actionWithSize:ccg(15,10) duration:t];
}
@end