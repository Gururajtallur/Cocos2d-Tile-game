//
//  MyGameScreen.h
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyGameConfig.h"
#import "PPCannonManager.h"

@class PPTileMapManager;
@class MyGame;
@class PPActor;
@class PPGuage;


@interface MyGameScreen : CCLayer
{
    PPTileMapManager    *mTileManager;
    
    bool                mIsGamePaused;

    MyGame             *sGame;
    PPActor            *mGameActor;

    
    CGPoint            mBeginSwip;
    bool               mAllowGageChange;
    
//    PPGuage            *mGuage;
//    PPCannonManager    *mCannonManager;
    
#if TARGET_IPHONE_SIMULATOR
    CGPoint mPrevTouch;
#endif
    
    //just used to find spritePosition 
#ifdef DEBUG
    CCSprite *mDebugSprite;
#endif
}

@property(nonatomic, retain) PPTileMapManager    *tileManager;
@property(nonatomic, retain) PPActor    *gameActor;
 

#ifdef DEBUG
@property(nonatomic, assign) CCSprite    *debugSprite;
#endif

+(CCScene *) scene;
@end
