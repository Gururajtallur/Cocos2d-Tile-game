//
//  MyGameConfig.h
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#ifndef PocketPirate_MyGameConfig_h
#define PocketPirate_MyGameConfig_h


 
#define ENABLE_RETINA_DISPLAY 1
#define USE_THREAD_FOR_LOADING_TILE_MAP 1

//-------------------------------------------------------------
/*                       Game Constants                      */
//-------------------------------------------------------------

#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)

#define TILE_SIZE       ( IS_IPAD ? 64 : 32 )
#define TILE_IN_ROW     ( IS_IPAD ? 19 : 19 )
#define TILE_IN_COL     ( IS_IPAD ? 32 : 30 )
#define MAX_GAME_SPEED  ( IS_IPAD ? (25.0f) : (8.0f) )

#define PIRATE_POSITION_Y ( IS_IPAD ? 155.0f : 80.0f )

#define CANNON_SPAN ( IS_IPAD ? 20.0f : 10.0f )



// Positions are generated using reference screen and debug sprite.
//-------------------------------------------------------------
/*                      UI POSITIONS                         */
//-------------------------------------------------------------

#define POS_UI_CHEST  ( (IS_IPAD) ? (ccp(72.0,831.0)) : (ccp(30.0,402.0)) )
#define POS_UI_ROUTE  ( (IS_IPAD) ? (ccp(74.0,452.0)) : (ccp(30.0,213.0)) )
#define POS_UI_GUAGE  ( (IS_IPAD) ? (ccp(384.0,70.0)) : (ccp(160.0,20.0)) )
#define POS_UI_BALL   ( (IS_IPAD) ? (ccp(384.0,70.0)) : (ccp(160.0,20.0)) )
#define POS_UI_COINS  ( (IS_IPAD) ? (ccp(608.0,955.0)) : (ccp(255.0,456.0)) )
#define POS_UI_TARGET ( (IS_IPAD) ? (ccp(608.0,893.0)) : (ccp(255.0,427.0)) )

#define POS_CANNON    ( (IS_IPAD) ? (ccp(368.0,170.0)) : (ccp(152.0,90.0)) )
//ccp(s.width*0.5f-8, PIRATE_POSITION_Y+10)  formula for cannon pos

#define POS_UI_START_INKY       ( (IS_IPAD) ? (ccp(82.0,359.0)) : (ccp(39.0,202.0)) )
#define POS_UI_START_PIRATE     ( (IS_IPAD) ? (ccp(92.0,567.0)) : (ccp(38.0,278.0)) )



//-------------------------------------------------------------
/*                       TILE MAP                            */
//-------------------------------------------------------------


#define PP_TILE_MAP_1_1         @"GameData/TileMap/PPTileMap_1_1.tmx"
#define PP_TILE_MAP_1_2         @"GameData/TileMap/PPTileMap_1_2.tmx"

#define PP_TILE_META_LAYER      @"Meta"
#define PP_TILE_MAP_BG_LAYER    @"Background"

#define TILE_PROPERTY_COLLIDABLE     @"collidable"
#define TILE_PROPERTY_COLLECTABLE    @"collectable"
#define TILE_PROPERTY_SEA            @"sea"

//-------------------------------------------------------------
/*                       SPRITE SHEET                        */
//-------------------------------------------------------------

#define SPRITE_SHEET_1          @"GameData/SpriteSheet/SpriteSheet_1.png"
#define SPRITE_COORD_1          @"GameData/SpriteSheet/SpriteSheet_1.plist"


#define UI_SPRITE_SHEET_1       @"GameData/SpriteSheet/GUIAtlas.png"
#define UI_SPRITE_COORD_1       @"GameData/SpriteSheet/GUIAtlas.plist"


#define CANNON_SPRITE_SHEET_1       @"GameData/SpriteSheet/SpriteSheet_Cannon.png"
#define CANNON_SPRITE_COORD_1       @"GameData/SpriteSheet/SpriteSheet_Cannon.plist"



//-------------------------------------------------------------
/*                       SPRITE FRAME                        */
//-------------------------------------------------------------

#define FRAM_ACTOR_1            @"Pirate_0.png"

#define FRAME_UI_ROUTE          @"UITEX_route.png"
#define FRAME_UI_BALL           @"UITEX_ball.png"
#define FRAME_UI_CHEST          @"UITEX_chest.png"
#define FRAME_UI_COINS          @"UITEX_coins.png"
#define FRAME_UI_GUAGE          @"UITEX_gauge.png"
#define FRAME_UI_INKY_PI        @"UITEX_inkyPirate.png"
#define FRAME_UI_PIRATES        @"UITEX_pirate.png"
#define FRAME_UI_TARGETS        @"UITEX_targets.png"
#define FRAME_CANNON_ANIM       @"cannonShoot_0000.png"

//-------------------------------------------------------------
/*                       LAYER LEVEL                         */
//-------------------------------------------------------------


#define LAYER_BACKGROUND    ( -4 )
#define LAYER_TILE_MAP      ( -3 )
#define LAYER_CANNON        ( -2 )
#define LAYER_PIRATE        ( -1 )


//--------------------------------------------------------------------------------
/*                                 SOUND EFFECT FILE                            */
//--------------------------------------------------------------------------------

NSString *const kSoundTap               = @"tap.caf";


//-------------------------------------------------------------
#define kOpenGLView           888
#define PTM_RATIO (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ? 100 : 32 )
//-------------------------------------------------------------

#import "MyGameTags.h"
#import "GLES-Render.h"


#endif
