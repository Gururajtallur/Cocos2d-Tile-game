//
//  AppDelegate.h
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright gururaj.tallur@gmail.com 2012. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "cocos2d.h"

@interface AppController : NSObject <UIApplicationDelegate, CCDirectorDelegate>
{
	UIWindow *window_;
	UINavigationController *navController_;
	
	CCDirectorIOS	*director_;							// weak ref
    
    UIInterfaceOrientation  mOrint;

}

@property (nonatomic, retain) UIWindow *window;
@property (readonly) UINavigationController *navController;
@property (readonly) CCDirectorIOS *director;
@property(nonatomic, assign) UIInterfaceOrientation orient;

@end
