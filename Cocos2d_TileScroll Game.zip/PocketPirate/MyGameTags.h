//
//  MyGameTags.h
//  PocketPirate
//
//  Created by Gururaj T on 03/09/12.
//  Copyright (c) 2012 gururaj.tallur@gmail.com. All rights reserved.
//

#ifndef PocketPirate_MyGameTags_h
#define PocketPirate_MyGameTags_h

/*---------------------------------------------------------------------*/

typedef enum
{
    kSceneFlashScreen = 1001,
    kSceneMainMenu,
    kSceneGameScreen,
}GameScreen;

/*---------------------------------------------------------------------*/

enum MyMainMenuTag 
{
    kTagBackground = 2001,
    kTagPlayBtnItem,
};

/*---------------------------------------------------------------------*/

enum MyGameScreenTag 
{
    kTagGameBackground = 3001,
    kTagTileMap,
    kTagGameActor,
    kTagCoinSprite,
    kTagUIRoute,
    kTagUIChest,
    kTagUIGuage,
    kTagUIBall,
    kTagUICoins,
    kTagUITargets,
    kTagUIInkyPirate,
    kTagUIPirate
    
};

/*---------------------------------------------------------------------*/

typedef enum GRID_TYPE{
	kGrideType_Normal = 4001,
    kGrideType_Collidable,
    kGrideType_Collectable,
    kGrideType_Sea,
    
    
    
}GridType;

/*---------------------------------------------------------------------*/

#endif
